package gvclib;

import net.minecraftforge.common.config.Configuration;

public class GVCConfig {
	public void init(Configuration config, mod_GVCLib mod)
	{
		mod.cfg_debag = config.getBoolean("debag", "all", false, "debag_mode");
		
		mod.cfg_debag_weather = config.getBoolean("debag_weather", "all", false, "debag_weather_mode");
		
		mod.cfg_debag_gun_mugen = config.getBoolean("cfg_debag_gun_mugen", "all", false, "cfg_debag_gun_mugen");
		
		mod.cfg_optifine	= config.getBoolean("optifine", "all", false, "debag_mode");
		mod.cfg_optifiney	= config.getFloat("cfg_optifiney", "all", (float)1.60D, 0, 20, "debag_mode");
		mod.cfg_optifineys	= config.getFloat("cfg_optifineys", "all", (float)1.54D, 0, 20,  "debag_mode");
		mod.cfg_bullet_smoke	= config.getBoolean("cfg_bullet_smoke", "all", false, "debag_mode");
		mod.cfg_bullet_living	= config.getInt("cfg_bullet_living", "all", 80, 0, 8000, "debag_mode");
		mod.cfg_Instant_death_avoidance	= config.getBoolean("cfg_Instant_death_avoidance", "all", true, "debag_mode");
		mod.cfg_explotion_drop	=config.getFloat("cfg_explotion_drop", "all", (float)1D, 0, 1, "debag_mode");
		
		mod.cfg_turret_lockpoint	= config.getBoolean("cfg_turret_lockpoint", "all", true, "debag_mode");
		
		mod.cfg_entity_render_range	= config.getFloat("cfg_entity_render_range", "all", (float)20D, 1, 100, "debag_mode");
		
		mod.cfg_explotion_breakdirt	= config.getBoolean("cfg_explotion_breakdirt", "all", true, "debag_mode");
		
		mod.cfg_mobdismount_insave	= config.getBoolean("cfg_mobdismount_insave", "all", true, "mob");
		
		mod.cfg_key_x	= config.getString("cfg_key_x", "all", "X", "KEY_X");
		mod.cfg_key_r	= config.getString("cfg_key_r", "all", "R", "KEY_R");
		mod.cfg_key_c	= config.getString("cfg_key_c", "all", "C", "KEY_C");
		mod.cfg_key_z	= config.getString("cfg_key_z", "all", "Z", "KEY_Z");
		mod.cfg_key_g	= config.getString("cfg_key_g", "all", "G", "KEY_G");
		mod.cfg_key_k	= config.getString("cfg_key_k", "all", "K", "KEY_K");
		mod.cfg_key_h	= config.getString("cfg_key_h", "all", "H", "KEY_H");
		mod.cfg_key_f	= config.getString("cfg_key_f", "all", "F", "KEY_F");
		mod.cfg_key_b	= config.getString("cfg_key_b", "all", "B", "KEY_B");
		mod.cfg_key_v	= config.getString("cfg_key_v", "all", "V", "KEY_V");
		
		mod.cfg_key_tab	= config.getString("cfg_key_tab", "all", "TAB", "KEY_TAB");
		
		
		//TODO -injection START
				mod.cfg_multiCoreLoading	= config.getBoolean("cfg_multiCoreLoading", "all", true, "debag_mode");
				//TODO -injection END
				
				
			//	mod.arm_alex	= config.getBoolean("arm_alex", "all", false, "arm");		
				mod.arm_lmm	= config.getBoolean("arm_lmm", "all", false, "arm");		
	}
}
